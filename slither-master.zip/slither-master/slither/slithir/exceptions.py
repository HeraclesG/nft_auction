from slither.exceptions import SlitherException


class SlithIRError(SlitherException):
    pass
