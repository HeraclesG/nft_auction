class SlitherException(Exception):
    pass


class SlitherError(SlitherException):
    pass
