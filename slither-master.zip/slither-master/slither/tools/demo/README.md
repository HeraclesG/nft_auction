# Demo

This directory contains an example of Slither utility.

See the [utility documentation](https://github.com/crytic/slither/wiki/Adding-a-new-utility)

