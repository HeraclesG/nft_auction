# slither-documentation

`slither-documentation` uses [codex](https://beta.openai.com) to generate natspec documenation.

This tool is experimental. See [solmate documentation](https://github.com/montyly/solmate/pull/1) for an example of usage.
