from slither.core.source_mapping.source_mapping import SourceMapping


class TopLevel(SourceMapping):
    """
    This class is used to represent objects that are at the top level
    The opposite is ContractLevel

    """
